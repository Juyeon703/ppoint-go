package dto

type RevenueAddDto struct {
	MemberId int
	Sales    int
	PayType  string
	SubPoint int
}
