package dto

type MemberSumSalesDto struct {
	TotalSales int
	TotalPoint int
}
