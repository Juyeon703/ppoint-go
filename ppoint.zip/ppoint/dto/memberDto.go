package dto

type MemberDto struct {
	MemberId    int
	MemberName  string
	PhoneNumber string
	Birth       string
	TotalPoint  int
	VisitCount  int
	CreateDate  string
	UpdateDate  string
}
