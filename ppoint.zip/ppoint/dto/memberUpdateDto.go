package dto

type MemberUpdateDto struct {
	MemberId    string
	MemberName  string
	PhoneNumber string
	Birth       string
	TotalPoint  string
	VisitCount  string
}
