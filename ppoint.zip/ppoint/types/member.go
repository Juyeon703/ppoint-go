package types

type Member struct {
	MemberId    int
	MemberName  string
	PhoneNumber string
	Birth       string
	TotalPoint  int
	VisitCount  int
	CreateDate  string
	UpdateDate  string
}
