package types

type Setting struct {
	SettingId          int
	SettingType        string
	SettingName        string
	SettingValue       int
	SettingDescription string
}
