package types

const Cash = "현금"
const Card = "카드"
