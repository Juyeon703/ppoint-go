package types

type Revenue struct {
	RevenueId  int
	MemberId   int
	Sales      int
	SubPoint   int
	AddPoint   int
	FixedSales int
	PayType    string
	CreateDate string
}
